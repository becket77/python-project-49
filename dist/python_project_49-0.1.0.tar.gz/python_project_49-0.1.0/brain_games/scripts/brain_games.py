#!/usr/bin/env python3
import brain_games.cli
from brain_games.cli import welcome_user

def main():
    return "Welcome to the Brain Games!"


if __name__ == '__main()__':
    main()
    welcome_user()
