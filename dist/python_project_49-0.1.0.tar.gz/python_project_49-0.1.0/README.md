### Hexlet tests and linter status:
[![Actions Status](https://github.com/becket77/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/becket77/python-project-49/actions)

<a href="https://codeclimate.com/github/becket77/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/7c32051f816a86c95876/maintainability" /></a>
